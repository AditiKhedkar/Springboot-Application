package com.example.demo.model;

public record Person(String name, int age) {}
